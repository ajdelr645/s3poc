console.log("Loading function");
var AWS = require("aws-sdk");


exports.handler = function(event, context) {
  
    var sns = new AWS.SNS()
    let BucketName = event['Records'][0]['s3']['bucket']['name']
    let Object = event['Records'][0]['s3']['object']['key']
    let Region =  event['Records'][0]['awsRegion']
    let Identity =  event['Records'][0]['userIdentity']['principalId']
    
    console.log( BucketName, Object, Region, Identity)
    let Message = "Hi Admin, an object "+ Object +  ' has been deleted by ' + Identity + ' belonging to the bucket ' + BucketName  + ' in Region ' + Region + ' Please take action Immediately.'
	let Subject = "S3 Bucket Object Delete Notification for S3 Bucket=" + BucketName 
	var params = {
		Message: Message, 
		Subject: Subject,
		TopicArn: process.env.TopicArn
	};  
    sns.publish(params, context.done);
};